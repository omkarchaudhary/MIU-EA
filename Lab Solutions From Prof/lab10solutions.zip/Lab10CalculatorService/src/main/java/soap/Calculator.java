package soap;

public class Calculator {
	private int value;
	
  public int add (int x) {
	  value = value + x;
	  return value;
  }
  public int subtract (int x) {
	  value = value - x;
	  return value;
  }
}
