package soap;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import generated.calc.CalcRequest;
import generated.calc.CalcResponse;




@Endpoint
public class CalcEndpoint {
	private static final String NAMESPACE_URI = "http://springtraining/calculator";
	Calculator calc = new Calculator();

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "CalcRequest")
	@ResponsePayload
	public CalcResponse getGreeting(@RequestPayload CalcRequest request) {
		CalcResponse response = new CalcResponse();
		int result = 0;
		int value = request.getInstruction().getValue();
		String operator = request.getInstruction().getOperator();
		
		if (operator.equals("+")) {
			result = calc.add(value);
		}
		if (operator.equals("-")) {
			result = calc.subtract(value);
		}
		response.setResult(result);
		return response;
	}
}



