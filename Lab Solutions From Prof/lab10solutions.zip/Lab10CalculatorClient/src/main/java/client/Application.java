package client;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context =
	              new AnnotationConfigApplicationContext(Application.class);
		CalcClient calcClient = context.getBean(CalcClient.class);
		int result;
		
		result = calcClient.calculate("+", 4);
		System.out.println(" + 4 gives "+result);
		
		result = calcClient.calculate("+", 8);
		System.out.println(" + 8 gives "+result);
		
		result = calcClient.calculate("-", 3);
		System.out.println(" - 3 gives "+result);
	}
}

