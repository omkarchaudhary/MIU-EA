package client;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import generated.*;

public class CalcClient extends WebServiceGatewaySupport {

	public int calculate(String operator, int value) {
		CalcRequest request = new CalcRequest();
		Instruction instruction = new Instruction();
		instruction.setOperator(operator);
		instruction.setValue(value);
		
		request.setInstruction(instruction);;
		
		CalcResponse response = (CalcResponse) 
				getWebServiceTemplate().marshalSendAndReceive(request);
		return response.getResult();
	}
}


